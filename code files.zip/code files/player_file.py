import pygame


class Player: 
    def __init__(self, x, y, width = 27, height = 50):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.base_speed = 4
        self.speed = self.base_speed

        # Dashing mechanics
        self.is_dashing = False
        self.dash_speed = 8
        self.dash_time = 150 #milliseconds
        self.dash_cooldown = 700
        self.dash_start_time = 0
        self.last_dash_time = -1000

        # Animation
        self.idle_img = pygame.image.load("assets/player/idle.png").convert_alpha()
        self.idle_img = pygame.transform.smoothscale(self.idle_img, (150, 112.5))

        self.walk_frames = [
            pygame.image.load("assets/player/walk_2.png").convert_alpha(),
            pygame.image.load("assets/player/walk_3.png").convert_alpha(),
            pygame.image.load("assets/player/walk_1.png").convert_alpha()
        ]
        self.walk_frames = [
            pygame.transform.smoothscale(img, (150, 112.5)) for img in self.walk_frames
        ]

        self.dash_img = pygame.image.load("assets/player/dash.png").convert_alpha()
        self.dash_img = pygame.transform.smoothscale(self.dash_img, (150,112.5))

        self.death_img = pygame.image.load("assets/player/death.png").convert_alpha()
        self.death_img = pygame.transform.smoothscale(self.death_img, (150, 112.5))

        self.anim_index = 0
        self.anim_timer = 0
        self.anim_speed = 5
        # To handle animations for different states
        self.state = 'idle'
        self.facing = 'right'

    def draw(self, s, offset, gamestate):
        rect = pygame.Rect(self.x - self.width/2 + offset[0] + 10, self.y - self.height/2 + offset[1], self.width, self.height)
        self.rect = rect

        if self.state == 'idle':
            img = self.idle_img
            if self.facing == 'left':
                img = pygame.transform.flip(img, True, False)

            s.blit(img, (self.x - 65 + offset[0], self.y - self.idle_img.get_height()//2 + offset[1]))
        #pygame.draw.rect(s, "red", rect)

        if self.state == 'walk':
            if gamestate == 'start': self.anim_timer += 1
            img = self.walk_frames[self.anim_index]
            if self.facing == 'left':
                img = pygame.transform.flip(img, True, False)
            s.blit(img, (self.x - 65 + offset[0], self.y - self.idle_img.get_height()//2 + offset[1]))

            if self.anim_timer >= self.anim_speed:
                self.anim_timer = 0
                # to cycle between animations
                self.anim_index = (self.anim_index + 1) % len(self.walk_frames) 
        
        if self.state == 'dash':
            img = self.dash_img
            if self.facing == 'left':
                img = pygame.transform.flip(img, True, False)

            s.blit(img, (self.x - 65 + offset[0], self.y - self.idle_img.get_height()//2 + offset[1]))
        if self.state == 'death':
            img = self.death_img
            if self.facing == 'left':
                img = pygame.transform.flip(img, True, False)
            s.blit(img, (self.x - 65 + offset[0], self.y - self.idle_img.get_height()//2 + offset[1]))

    def move_x(self):
        pressed = pygame.key.get_pressed()
        current_time = pygame.time.get_ticks()

        if pressed[pygame.K_a] or pressed[pygame.K_d] or pressed[pygame.K_LEFT] or pressed[pygame.K_RIGHT]:

            # Dash
            if pressed[pygame.K_SPACE] and not self.is_dashing: 
                if current_time - self.last_dash_time >= self.dash_cooldown:
                    self.is_dashing = True
                    self.dash_start_time = current_time
                    self.last_dash_time = current_time
                    self.speed = self.dash_speed
            
            if pressed[pygame.K_a] or pressed[pygame.K_LEFT]:
                self.x -= self.speed
                self.facing = 'left'
            if pressed[pygame.K_d] or pressed[pygame.K_RIGHT]:
                self.x += self.speed
                self.facing = 'right'
        
        if self.is_dashing:
            self.width = 45
            if current_time - self.dash_start_time >= self.dash_time:
                self.is_dashing = False
        
        if not self.is_dashing and self.speed > self.base_speed:
            self.width = 27
            self.speed -= 0.2
            if self.speed < self.base_speed:
                self.speed = self.base_speed

    def move_y(self):
        pressed = pygame.key.get_pressed()
        current_time = pygame.time.get_ticks()

        if pressed[pygame.K_w] or pressed[pygame.K_s] or pressed[pygame.K_UP]or pressed[pygame.K_DOWN]:

            if pressed[pygame.K_SPACE] and not self.is_dashing: 
                if current_time - self.last_dash_time >= self.dash_cooldown:
                    self.is_dashing = True
                    self.dash_start_time = current_time
                    self.last_dash_time = current_time
                    self.speed = self.dash_speed
            
            if pressed[pygame.K_w] or pressed[pygame.K_UP]:
                self.y -= self.speed
            elif pressed[pygame.K_s] or pressed[pygame.K_DOWN]:
                self.y += self.speed 
        

        if self.is_dashing:
            if current_time - self.dash_start_time >= self.dash_time:
                self.is_dashing = False
        if not self.is_dashing and self.speed > self.base_speed:
            self.speed -= 0.25
            if self.speed < self.base_speed:
                self.speed = self.base_speed

    def offset_change_x(self, offset, SCREEN_WIDTH) :
        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_a] or pressed[pygame.K_LEFT]:
            offset[0] += self.speed
        if pressed[pygame.K_d] or pressed[pygame.K_RIGHT]:
            offset[0] -= self.speed
        if pressed[pygame.K_c]:
            if offset[0] == SCREEN_WIDTH/2 - self.x : pass
            elif offset[0] < SCREEN_WIDTH/2 - self.x : 
                offset[0] += 2
                if -offset[0] + (SCREEN_WIDTH/2 - self.x) <=5 : offset[0] = SCREEN_WIDTH/2 - self.x
            elif offset[0] > SCREEN_WIDTH/2 - self.x : 
                offset[0] -= 2
                if offset[0] - (SCREEN_WIDTH/2 - self.x) <=5 : offset[0] = SCREEN_WIDTH/2 - self.x
                

    def offset_change_y(self, offset, SCREEN_HEIGHT):
        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_w] or pressed[pygame.K_UP]:
            offset[1] += self.speed 
        if pressed[pygame.K_s] or pressed[pygame.K_DOWN]:
            offset[1] -= self.speed
        if pressed[pygame.K_c]:
            if offset[1] == SCREEN_HEIGHT/2 - self.y : pass
            elif offset[1] < SCREEN_HEIGHT/2 - self.y : 
                offset[1] += 1.25
                if -offset[1] + (SCREEN_HEIGHT/2 - self.y) <=5 : offset[1] = SCREEN_HEIGHT/2 - self.y
            elif offset[1] > SCREEN_HEIGHT/2 - self.y : 
                offset[1] -= 1.25
                if offset[1] - (SCREEN_HEIGHT/2 - self.y) <=5 : offset[1] = SCREEN_HEIGHT/2 - self.y

    def update_state(self):
        pressed = pygame.key.get_pressed()

        if self.is_dashing:
            self.state = 'dash'
        elif pressed[pygame.K_a] or pressed[pygame.K_d] or pressed[pygame.K_w] or pressed[pygame.K_s] or pressed[pygame.K_LEFT] or pressed[pygame.K_RIGHT] or pressed[pygame.K_UP] or pressed[pygame.K_DOWN]:
            self.state = "walk"
        else :
            self.state = 'idle'