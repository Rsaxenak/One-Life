import pygame
import random

class SquareEnemies:
    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT, size = 40):
        self.direction = random.choice(["up", "down", "left", "right"])
        
        if self.direction == "up" or self.direction == "down":
            self.x = random.randint(20, SCREEN_WIDTH - 20)
            self.y = 10 if self.direction == "down" else SCREEN_HEIGHT - 10
        if self.direction == "left" or self.direction == "right":
            self.y = random.randint(20, SCREEN_HEIGHT - 20)
            self.x = 10 if self.direction == "right" else SCREEN_WIDTH - 10

        self.image = pygame.image.load("assets/enemies/square.png").convert_alpha()
        scale = 0.14
        self.image_w, self.image_h = self.image.get_width() * scale, self.image.get_height() * scale
        self.image = pygame.transform.smoothscale(self.image, (self.image_w, self.image_h))
        self.speed = 3
        self.type = 'square'
        self.width = size
        self.height = size

    def draw(self, s, offset, color):
        s.blit(self.image, (self.x - self.image_w//2 + offset[0], self.y - self.image_h//2 + offset[1]))
        self.rect = pygame.Rect(self.x - self.width/2 + offset[0], self.y - self.height/2 + offset[1], self.width, self.height)
        #pygame.draw.rect(s, color, self.rect)

    def move(self, border_left, border_right, border_up, border_down):
        
        if self.direction == "up":
            self.y -= self.speed
        if self.direction == "down":
            self.y += self.speed
        if self.direction == "left":
            self.x -= self.speed
        if self.direction == "right":
            self.x += self.speed
        
        if self.x - self.width/2 < border_left and self.direction == "left":
            self.direction = "right"
        if self.x + self.width/2 > border_right and self.direction == "right":
            self.direction = "left"
        if self.y - self.height/2 < border_up and self.direction == "up":
            self.direction = "down"
        if self.y + self.height/2 > border_down and self.direction == "down":
            self.direction = "up"

