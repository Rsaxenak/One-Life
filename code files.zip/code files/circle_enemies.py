import pygame
import random

class CircleEnemies():
    def __init__(self, SCREEN_WIDTH = 800, SCREEN_HEIGHT = 600):
        self.x = random.randint(30, SCREEN_WIDTH - 30)
        self.y = random.randint(30, SCREEN_HEIGHT - 30)

        self.radius = 20
        self.type = "circle"

        self.base_radius = 20
        self.max_radius = 100

        self.cool_img = pygame.image.load("assets/enemies/circle_calm.png").convert_alpha()
        self.cool_scale = 0.4
        self.cool_img_w, self.cool_img_h = self.cool_img.get_width() * self.cool_scale, self.cool_img.get_height() * self.cool_scale
        self.cool_img = pygame.transform.smoothscale(self.cool_img, (self.cool_img_w * self.cool_scale, self.cool_img_h * self.cool_scale))

        self.ang_img = pygame.image.load("assets/enemies/circle_angry.png").convert_alpha()
        self.ang_org_scale = 0.15


        self.enlarge_speed = 1
        self.state = "enlarging"
        self.cooldown = 10
        self.cooldown_speed = 0.1
        self.time = 0

    def draw(self, s, offset, color):
        self.rect = pygame.Rect(self.x - self.radius/1.414 + offset[0], self.y - self.radius/1.414 + offset[1], self.radius * 1.414, self.radius * 1.414)
        
        # To avoid constantly increasing the size of the image, we create a shallow copy
        
        scale_factor = self.ang_org_scale * self.radius/self.base_radius

        ang_w = self.ang_img.get_width() * scale_factor
        ang_h = self.ang_img.get_height() * scale_factor        
        ang_img = pygame.transform.smoothscale(self.ang_img, (ang_w, ang_h))
        
        if self.state == 'cooldown':
            self.ang_scale = self.ang_org_scale
            s.blit(self.cool_img, (self.x - self.cool_img_w//2 * self.cool_scale + offset[0] + 1, self.y - self.cool_img_h//2 * self.cool_scale+ offset[1] + 1))
        if self.state == 'enlarging':
            s.blit(ang_img, (self.x - ang_w//2 + offset[0], self.y - ang_h//2 + offset[1]))


        #pygame.draw.circle(s, color, (self.x + offset[0], self.y + offset[1]), self.radius)

        #pygame.draw.rect(s, "red", self.rect)

    def enlarge(self):

        if self.state == "enlarging":
            self.radius += self.enlarge_speed
            if self.radius >= self.max_radius:
                self.state = "cooldown"
        if self.state == "cooldown":
            self.radius = self.base_radius
            self.time += self.cooldown_speed
            if self.time >= self.cooldown:
                self.state = "enlarging"
                self.time = 0