import pygame
import random
import math

class TriangleEnemies():
    def __init__(self, player, SCREEN_WIDTH, SCREEN_HEIGHT):
        self.x = random.randint(20, SCREEN_WIDTH - 20)
        self.y = random.randint(20, SCREEN_HEIGHT - 20)

        self.radius = 30
        self.speed = 3
        self.type = "triangle"
        self.image = pygame.image.load("assets/enemies/triangle_cropped.png").convert_alpha()
        scale = 0.15
        self.image_w, self.image_h = self.image.get_width() * scale, self.image.get_height() * scale
        self.image = pygame.transform.smoothscale(self.image, (self.image_w, self.image_h))
        
    
        self.set_velocity(player)

    def draw(self, s, offset, color):    
        self.rect = pygame.Rect(self.x - self.radius * math.sqrt(3) * 0.25 + offset[0], self.y - self.radius + offset[1], self.radius * math.sqrt(3) * 0.5, self.radius * math.sqrt(3))  
        s.blit(self.image, (self.x - self.image_w//2 + offset[0], self.y - self.image_h//2 - 5 + offset[1]))
        
    
    def set_velocity(self, p):
        dx = p.x - self.x
        dy = p.y - self.y

        length = math.sqrt(dx * dx + dy * dy)
        if length == 0:
            length = 0.1
        
        ux, uy = dx/length, dy/length
        self.vx, self.vy = ux * self.speed, uy * self.speed
    
    def move(self, p):
        self.x += self.vx
        self.y += self.vy
        self.set_velocity(p)