import pygame
import random
from player_file import Player
from square_enemies import SquareEnemies
from hexagon_enemies import HexagonEnemies
from circle_enemies import CircleEnemies
from triangle_enemies import TriangleEnemies
from powerups import PowerUps

# initialize pygame
pygame.init()
pygame.display.set_caption("One Life")
pygame.display.set_icon(pygame.image.load('assets/buttons/icon.png'))

SCREEN_WIDTH = 960
SCREEN_HEIGHT = 720

WORLD_WIDTH = 960
WORLD_HEIGHT = 720


gamestate = "menu"

# Score
score = 0

# walls logic : 0 = not hitting, 1 = hitting
player_wall_state_x = 0
player_wall_state_y = 0
player_wall_state = [0, 0]

#powerup
power_state = 'none'
power_tick = 0
power_cooldown = 500
power_chance = 0

# Colors
gray = (128, 128, 128)

offset = [0, 0]

# Screen variable
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))




# Borders class, to prevent player from going far
class Borders:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    def draw(self, s = screen):
        rect = pygame.Rect(self.x + offset[0], self.y + offset[1], self.width, self.height)
        pygame.draw.rect(s, gray, rect)

class Buttons:
    def __init__(self, x, y, place, image, high_img, width = 285, height = 65):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        self.state = 0 # 0 for normal, 1 for highlighted
        self.place = place

        scale = 0.5
        self.image = image
        self.img_w, self.img_h = self.image.get_width() * scale, self.image.get_height() * scale
        self.image = pygame.transform.smoothscale(self.image, (self.img_w, self.img_h))

        self.high_img = high_img
        self.high_img_w, self.high_img_h = self.high_img.get_width() * scale, self.high_img.get_height() * scale
        self.high_img = pygame.transform.smoothscale(self.high_img, (self.high_img_w, self.high_img_h))
        self.rect = pygame.Rect(self.x - self.width/2, self.y - self.height/2, self.width, self.height)

        
    def draw(self, s = screen):
        self.rect = pygame.Rect(self.x - self.width/2, self.y - self.height/2, self.width, self.height)        
        #pygame.draw.rect(s, gray, self.rect)
    
        if self.state == 0: s.blit(self.image, (self.x - self.img_w//2, self.y - self.img_h//2)) 
        elif self.state == 1 : s.blit(self.high_img, (self.x - self.high_img_w//2, self.y - self.high_img_h//2))

def kill_enemy(enemy):
    global gamestate
    if player.rect.colliderect(enemy.rect):
        if player.is_dashing or power_state == 'invincible':
            enemies.remove(enemy)
            score_add(1)
        else :
            gamestate = "death"


def restart(state = 'start'):
    global gamestate, score, wave, power_state
    player.x = 480
    player.y = 360
    player.state = 'idle'
    offset[0], offset[1] = 0, 0
    for i in range(len(enemies)):
        enemies.pop()
    score = 0
    wave = 1
    gamestate = state
    power_state = 'none'

def score_add(add):
    global score, power_chance
    score += add

    if score >= 5:
        power_chance = random.randint(1, 100)
    if power_chance >= 90: 
        enemies.append(PowerUps(SCREEN_WIDTH, SCREEN_HEIGHT))
        power_chance = 0


# Clock variable
clock = pygame.time.Clock()

# Initializing player
player = Player(480, 360)

# Creating enemies list
enemies = []
enemy_tick = 0

# Borders
border_left = Borders(-10, 0, 10, 720)
border_up = Borders(0, -10, 960, 10)
border_right = Borders(960, 0, 10, 720)
border_down = Borders(0, 720, 960, 10)

# ui images
title_img = pygame.image.load("assets/buttons/title.png").convert_alpha()
title_img = pygame.transform.smoothscale(title_img, (title_img.get_width() * 0.6, title_img.get_height() * 0.6))

tut_img = pygame.image.load("assets/buttons/tutorial.png").convert_alpha()
tut_img = pygame.transform.smoothscale(tut_img, (tut_img.get_width() * 0.6, tut_img.get_height() * 0.6))

death_screen = pygame.image.load("assets/buttons/death_screen.png").convert_alpha()
death_screen = pygame.transform.smoothscale(death_screen, (death_screen.get_width() * 0.6, death_screen.get_height() * 0.6))

#Buttons
start_button = Buttons(320, 360,'menu', pygame.image.load("assets/buttons/start.png").convert_alpha(), 
                       pygame.image.load("assets/buttons/start_highlighted.png").convert_alpha())
how_to_play_button = Buttons(620, 360,'menu', pygame.image.load("assets/buttons/how_to_play.png").convert_alpha(),
                              pygame.image.load("assets/buttons/how_to_play_highlighted.png").convert_alpha())
quit_button = Buttons(470, 460,'menu', pygame.image.load("assets/buttons/quit.png").convert_alpha(),
                       pygame.image.load("assets/buttons/quit_highlighted.png").convert_alpha())
close_button = Buttons(470, 600,'tutorial',
                       pygame.image.load("assets/buttons/close.png").convert_alpha(),
                       pygame.image.load("assets/buttons/close_highlighted.png").convert_alpha())


buttons = [start_button, how_to_play_button, quit_button, close_button]

#background image
background_images =  [
    pygame.image.load("assets/background/background_1.png").convert_alpha(),
    pygame.image.load("assets/background/background.png").convert_alpha(),
    pygame.image.load("assets/background/background_2.png").convert_alpha(),
    pygame.image.load("assets/background/background.png").convert_alpha()
]

background_scale = 1.25
background_images = [pygame.transform.smoothscale(img, (img.get_width() * background_scale, img.get_height() * background_scale)) for img in background_images]
background_anim_timer = 0
background_anim_speed = 30
background_anim_index = 0

# setting font
font = pygame.font.SysFont("Courier", 20, True)

running = True
while running:
    screen.blit(background_images[background_anim_index], 
                (WORLD_WIDTH/2 - background_images[background_anim_index].get_width()//2 + offset[0] + 20,
                 WORLD_HEIGHT/2 - background_images[background_anim_index].get_height()//2 + offset[1] + 20))
    pressed = pygame.key.get_pressed()

    score_text = font.render(f'Score : {score}', True, 'white')
    if gamestate == 'start' or gamestate == 'death': 
        score_rec = pygame.image.load('assets/buttons/base.png').convert_alpha()
        score_rec = pygame.transform.smoothscale(score_rec, (score_rec.get_width() * 0.3, score_rec.get_height() * 0.2))
        screen.blit(score_rec, (460 - score_rec.get_width()//2, 50 - score_rec.get_height()//2))
        screen.blit(score_text, (410, 40))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONUP:
            if gamestate == 'menu':
                if start_button.rect.collidepoint(pygame.mouse.get_pos()):
                    restart()
                if how_to_play_button.rect.collidepoint(pygame.mouse.get_pos()):
                    gamestate = 'tutorial'
                if quit_button.rect.collidepoint(pygame.mouse.get_pos()):
                    running = False
            if gamestate == 'tutorial' or gamestate == 'death':    
                if close_button.rect.collidepoint(pygame.mouse.get_pos()):
                    restart('menu')

    if gamestate == 'menu':
        screen.blit(title_img, (470 - title_img.get_width()/2, 200 - title_img.get_height()/2))

    # creating a shallow copy to prevent the loop from skipping a member
    for enemy in enemies[:]:
        if enemy.type == "square":
            enemy.draw(screen, offset, gray)
            if gamestate == "start": 
                enemy.move(border_left.x + border_left.width, border_right.x, border_up.y + border_up.height, border_down.y)
            kill_enemy(enemy)
            if power_state != 'slow':
                if score >= 10: enemy.speed = 3 + score/20
                else : enemy.speed = 3

        if enemy.type == "hexagon":
            enemy.draw(screen, offset, gray)
            if gamestate == "start":
                enemy.move(WORLD_WIDTH, WORLD_HEIGHT)
            kill_enemy(enemy)
            if power_state != 'slow':
                if score >= 15: enemy.speed = 3 + score/30
                else : enemy.speed = 3

        if enemy.type == "circle":
            enemy.draw(screen, offset, gray)
            if gamestate == "start":
                enemy.enlarge()
            if player.rect.colliderect(enemy.rect):
                if (player.is_dashing and enemy.state == "cooldown") or power_state == 'invincible':
                    enemies.remove(enemy)
                    score_add(1)
                else : 
                    if enemy.state == 'enlarging': gamestate = "death"
            if power_state != 'slow':
                enemy.enlarge_speed = 1


        if enemy.type == "triangle":
            enemy.draw(screen,offset,gray)
            if gamestate == "start":
                enemy.move(player)
            kill_enemy(enemy)
            if power_state != "slow":
                if score >= 30: enemy.speed = 3 + (score - 20)/30
                else: enemy.speed = 3

        if enemy.type == 'powerup':
            enemy.draw(screen, offset)
            if player.rect.colliderect(enemy.rect):
                enemies.remove(enemy)
                power_state = random.choice(('speed', 'slow', 'invincible'))
                power_tick = 0

        if power_state == 'slow':
            if enemy.type != 'circle': enemy.speed = 1.25
            else: enemy.enlarge_speed = 0.5



    if gamestate == "start":    
        # Implementing wallsystem
        if player.x - player.width/2 >= border_left.x + border_left.width and player.x - player.width/2<= border_right.x - player.width:
            player.move_x()
            if player.x - player.width/2> border_left.x + border_left.width and player.x - player.width/2< border_right.x - player.width: 
                player_wall_state[0] = 0
        else :
            player_wall_state[0] = 1
            if player.x - player.width/2< border_left.x + border_left.width:
                player.x = border_left.x + border_left.width + player.width/2
            if player.x - player.width/2> border_right.x - player.width:
                player.x = border_right.x - player.width + player.width/2

        if player.y - player.height/2>= border_up.y + border_up.height and player.y - player.height/2<= border_down.y - player.height:
            player.move_y()
            if player.y - player.height/2> border_up.y + border_up.height and player.y - player.height/2 < border_down.y - player.height: 
                player_wall_state[1] = 0
        else :
            player_wall_state[1] = 1
            if player.y - player.height/2 < border_up.y + border_up.height:
                player.y = border_up.y + border_up.height + player.height/2
            if player.y - player.height/2 > border_down.y - player.height:
                player.y = border_down.y - player.height + player.height/2

        if not player_wall_state[0]: player.offset_change_x(offset, WORLD_WIDTH)
        if not player_wall_state[1]: player.offset_change_y(offset, WORLD_HEIGHT)

        if power_state == 'speed':
            player.speed = player.base_speed = 6
            player.dash_speed = 16
            player.dash_cooldown = 900
        else :
            player.base_speed = 4
            player.dash_speed = 8
            player.dash_cooldown = 700

        if power_state != 'none':
            power_tick += 1
            power_text = font.render(f"{power_state}".capitalize(), True, (242, 238, 11) if power_tick < power_cooldown - 100 else 'red')
            screen.blit(power_text, (700, 20))
            if power_tick >= power_cooldown:
                power_tick = 0
                power_state = 'none'
                print(power_state)
                

        
        # enemy spawning system
        enemy_tick += 1

        if enemy_tick >= 100 - (score/2 if score < 50 else 75) and len(enemies) < 5:
            enemy_tick = 0
            enemies.append(SquareEnemies(WORLD_WIDTH, WORLD_HEIGHT) if score//5 in (0, 1, 2)
                           else random.choice((SquareEnemies(WORLD_WIDTH, WORLD_HEIGHT), HexagonEnemies(WORLD_WIDTH, WORLD_HEIGHT))) if score//5 == 3
                           else random.choice((SquareEnemies(WORLD_WIDTH, WORLD_HEIGHT), HexagonEnemies(WORLD_WIDTH, WORLD_HEIGHT), CircleEnemies(WORLD_WIDTH, WORLD_HEIGHT))) if score//5 == 4
                           else random.choice((SquareEnemies(WORLD_WIDTH, WORLD_HEIGHT), HexagonEnemies(WORLD_WIDTH, WORLD_HEIGHT), CircleEnemies(WORLD_WIDTH, WORLD_HEIGHT), TriangleEnemies(player, WORLD_WIDTH, WORLD_HEIGHT))))

                
        #background
        background_anim_timer += 1

        if background_anim_timer >= background_anim_speed:
            background_anim_timer = 0
            background_anim_index = (background_anim_index + 1) % len(background_images)

    if gamestate not in ['menu', 'tutorial']: player.draw(screen, offset, gamestate)        
    
    if gamestate == "death":
        player.state = 'death'
        close_button.place = 'death'
        screen.blit(death_screen, (470 - death_screen.get_width()/2, 300 - death_screen.get_height()/2))
        if pressed[pygame.K_r]:
            restart()

    if gamestate == 'start': player.update_state()

    # draw functions
    

    if gamestate == 'tutorial':
        screen.blit(tut_img, (470 - tut_img.get_width()/2, 300 - tut_img.get_height()/2))
        close_button.place = 'tutorial'
    
    for button in buttons:
        if gamestate == button.place:
            button.draw()
            if button.rect.collidepoint(pygame.mouse.get_pos()):
                button.state = 1
            else : button.state = 0
    #border_left.draw()
    #border_up.draw()
   # border_down.draw()
   # border_right.draw()


    clock.tick(60)
    pygame.display.update()