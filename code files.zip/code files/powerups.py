import pygame
import random

class PowerUps():
    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT):
        self.x = random.randint(20, SCREEN_WIDTH - 20)
        self.y = random.randint(20, SCREEN_HEIGHT - 20)

        self.width = 40
        self.height = 40
        self.type = 'powerup'

        self.image = pygame.image.load("assets/powerup.png").convert_alpha()
        scale = 0.2
        self.img_w, self.img_h = self.image.get_width() * scale, self.image.get_height() * scale
        self.image = pygame.transform.smoothscale(self.image, (self.img_w, self.img_h))

    def draw(self, s, offset):
        self.rect = pygame.Rect(self.x - self.width/2 + offset[0], self.y - self.height/2 + offset[1], self.width, self.height)
        s.blit(self.image, (self.x - self.img_w//2 + offset[0], self.y - self.img_h//2 + offset[1]))
        #pygame.draw.rect(s, 'green', self.rect)

    