import pygame
import random
import math

class HexagonEnemies():
    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT):
        
        self.x = random.randint(10, SCREEN_WIDTH - 10)
        self.y = random.randint(10, SCREEN_HEIGHT - 10)
        self.radius = 30
        self.speed = 3
        self.type = 'hexagon'

        self.new_x = random.randint(20, SCREEN_WIDTH - 20)
        self.new_y = random.randint(20, SCREEN_HEIGHT - 20)

        self.image = pygame.image.load("assets/enemies/hexagon.png").convert_alpha()
        scale = 0.2
        self.image_w, self.image_h = self.image.get_size() 
        self.image_w, self.image_h = self.image_w * scale, self.image_h * scale
        self.image = pygame.transform.smoothscale(self.image, (self.image_w, self.image_h))

        self.set_velocity()


    def draw(self, s, offset, color):
        s.blit(self.image, (self.x - self.image_w//2 + offset[0], self.y - self.image_h//2 + offset[1]))
        
        self.rect = pygame.Rect(self.x - self.radius/2 - 5 + offset[0], self.y - self.radius* math.sqrt(3) * 0.5 + offset[1] + 5, self.radius + 15, math.sqrt(3) * self.radius - 5)
        #pygame.draw.rect(s, color, self.rect)

    def set_velocity(self):
        dx = self.new_x - self.x
        dy = self.new_y - self.y
        length = math.sqrt(dx * dx + dy * dy)

        if length == 0 : 
            self.vx = 0
            self.vy = 0
            return

        ux, uy = dx/length, dy/length
        self.vx, self.vy = ux * self.speed, uy * self.speed


    def move(self, SCREEN_WIDTH, SCREEN_HEIGHT):
        self.x += self.vx
        self.y += self.vy

        if abs(self.new_x - self.x) < self.speed and abs(self.new_y - self.y) < self.speed:
            self.new_x = random.randint(20, SCREEN_WIDTH - 20)
            self.new_y = random.randint(20, SCREEN_HEIGHT - 20)
            self.set_velocity()

        